export class Address {
    id: number;
	address: string;
	city: string;
	state: string;
	zipcode: number;
}